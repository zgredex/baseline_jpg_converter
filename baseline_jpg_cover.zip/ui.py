#!/usr/bin/env python
# -*- coding: utf-8 -*-

from calibre.gui2.actions import InterfaceAction
from calibre.gui2 import error_dialog, info_dialog
from qt.core import QProgressDialog, Qt

class BaselineJPGAction(InterfaceAction):
    name = 'Baseline JPEG Converter'
    action_spec = ('Baseline JPEG Converter', None, 'Convert covers and EPUB images to baseline JPEG', None)
    action_type = 'current'
    
    def genesis(self):
        self.qaction.triggered.connect(self.convert_covers)
        
    def convert_covers(self):
        rows = self.gui.library_view.selectionModel().selectedRows()
        if not rows:
            error_dialog(self.gui, 'No Selection', 
                        'Please select one or more books first.', show=True)
            return
        
        book_ids = list(map(self.gui.library_view.model().id, rows))
        self.do_convert(book_ids)
    
    def convert_image_to_baseline(self, image_data):
        from PIL import Image
        from io import BytesIO
        
        try:
            img = Image.open(BytesIO(image_data))
            
            if img.format != 'JPEG':
                return None
            
            if img.mode in ('RGBA', 'LA', 'P'):
                img = img.convert('RGB')
            
            output = BytesIO()
            img.save(output, format='JPEG', quality=85, progressive=False, optimize=False)
            return output.getvalue()
        except Exception:
            return None
    
    def convert_epub_images(self, epub_path):
        import zipfile
        import tempfile
        import os
        import shutil
        
        converted_count = 0
        
        temp_fd, temp_path = tempfile.mkstemp(suffix='.epub')
        os.close(temp_fd)
        
        try:
            with zipfile.ZipFile(epub_path, 'r') as zin:
                with zipfile.ZipFile(temp_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                    for item in zin.infolist():
                        data = zin.read(item.filename)
                        
                        lower_name = item.filename.lower()
                        if lower_name.endswith(('.jpg', '.jpeg')):
                            new_data = self.convert_image_to_baseline(data)
                            if new_data:
                                data = new_data
                                converted_count += 1
                        
                        if item.filename == 'mimetype':
                            zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
                        else:
                            zout.writestr(item, data)
            
            shutil.move(temp_path, epub_path)
            
        except Exception as e:
            if os.path.exists(temp_path):
                os.remove(temp_path)
            raise e
        
        return converted_count
    
    def do_convert(self, book_ids):
        from PIL import Image
        from io import BytesIO
        import os
        
        db = self.gui.current_db.new_api
        converted_covers = 0
        converted_epub_images = 0
        errors = []
        
        progress = QProgressDialog('Converting images...', 'Cancel', 0, len(book_ids), self.gui)
        progress.setWindowModality(Qt.WindowModal)
        progress.setWindowTitle('Converting to Baseline JPEG')
        
        for i, book_id in enumerate(book_ids):
            if progress.wasCanceled():
                break
                
            progress.setValue(i)
            title = db.field_for('title', book_id)
            progress.setLabelText(f'Processing: {title}\n({i+1} of {len(book_ids)})')
            
            try:
                cover_data = db.cover(book_id)
                if cover_data:
                    img = Image.open(BytesIO(cover_data))
                    
                    if img.mode in ('RGBA', 'LA', 'P'):
                        img = img.convert('RGB')
                    
                    output = BytesIO()
                    img.save(output, format='JPEG', quality=85, progressive=False, optimize=False)
                    new_data = output.getvalue()
                    
                    db.set_cover({book_id: new_data})
                    converted_covers += 1
            except Exception as e:
                errors.append(f'{title} (cover): {str(e)}')
            
            try:
                formats = db.formats(book_id)
                if formats and 'EPUB' in formats:
                    epub_path = db.format_abspath(book_id, 'EPUB')
                    if epub_path and os.path.exists(epub_path):
                        count = self.convert_epub_images(epub_path)
                        converted_epub_images += count
            except Exception as e:
                errors.append(f'{title} (EPUB): {str(e)}')
        
        progress.setValue(len(book_ids))
        
        msg = f'Successfully converted {converted_covers} cover(s) and {converted_epub_images} EPUB image(s) to baseline JPEG.'
        if errors:
            msg += f'\n\nErrors ({len(errors)}):\n' + '\n'.join(errors[:10])
            if len(errors) > 10:
                msg += f'\n... and {len(errors) - 10} more'
        
        info_dialog(self.gui, 'Conversion Complete', msg, show=True)
        
        if converted_covers > 0:
            self.gui.library_view.model().refresh_ids(book_ids)
            self.gui.cover_flow.dataChanged()
            self.gui.tags_view.recount()
